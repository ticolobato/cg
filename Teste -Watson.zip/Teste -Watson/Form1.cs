﻿using IBM.WatsonDeveloperCloud;
using IBM.WatsonDeveloperCloud.NaturalLanguageUnderstanding.v1;
using IBM.WatsonDeveloperCloud.NaturalLanguageUnderstanding.v1.Model;
using IBM.WatsonDeveloperCloud.Util;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Teste__Watson
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Analisar("I hate potato");
        }

        private void Analisar(string comentario)
        {/*
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.ASCII.GetBytes("apikey:ExagR9tDw7JL-wfLFu1fa_noqPiaa2iWOWgluAMVwt8a")));

            string postData = "{\"text\": \"" + comentario + "\"}";
            var response = client.PostAsync("https://gateway.watsonplatform.net/natural-language-understanding/api", new StringContent(postData, Encoding.UTF8, "application/json")).Result;
            var responseContent = response.Content.ReadAsStringAsync().Result;
            Console.WriteLine(responseContent);
            */
            TokenOptions iamAssistantTokenOptions = new TokenOptions()
            {
                IamApiKey = "ExagR9tDw7JL-wfLFu1fa_noqPiaa2iWOWgluAMVwt8a"
               
            };

            NaturalLanguageUnderstandingService _naturalLanguageUnderstandingService = new NaturalLanguageUnderstandingService(iamAssistantTokenOptions, "2018-11-16");

            Parameters parameters = new Parameters()
            {
                Text = textBox1.Text,
                Features = new Features()
                {
                    Sentiment = new SentimentOptions()
                    {
                        Document = true,
                    },
                    Emotion = new EmotionOptions()
                    {
                        Document = true,
                    }
                }
            };

            var result = _naturalLanguageUnderstandingService.Analyze(parameters);
            if (result.Sentiment.Document.Label.Equals("negative")){
                label4.Text = "Sentimento geral: Negativo";
            }
            else
            {
                label4.Text = "Sentimento geral: Positivo";
            }
            
            label5.Text = "Nível: "+ result.Sentiment.Document.Score;
            label7.Text = "Tristeza: " + result.Emotion.Document.Emotion.Sadness;
            label8.Text = "Alegria: " + result.Emotion.Document.Emotion.Joy;
            label9.Text = "Medo: " + result.Emotion.Document.Emotion.Fear;
            label10.Text = "Desgosto: " + result.Emotion.Document.Emotion.Disgust;
            label11.Text = "Raiva: " + result.Emotion.Document.Emotion.Anger;
          
        }




    }
}
