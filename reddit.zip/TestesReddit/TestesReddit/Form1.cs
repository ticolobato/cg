﻿using HtmlAgilityPack;
using RedditSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static RedditSharp.Things.VotableThing;

namespace TestesReddit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            ParseHTML();




        }

        public void ParseHTML()
        {
            /*var html = @"https://www.reddit.com/r/hearthstone/comments/9odyk3/upcoming_balance_update_october_2018/";

            HtmlWeb web = new HtmlWeb();

            var htmlDoc = web.Load(html);

            foreach (HtmlNode node in htmlDoc.DocumentNode.SelectNodes("//div/p/text()"))
            {
                Console.WriteLine("text=" + HtmlEntity.DeEntitize(node.InnerText));
            }*/

            var reddit = new Reddit();
            var user = reddit.LogIn("ticolobato", "t4414144");
            System.Uri uri = new System.Uri("https://www.reddit.com/r/CompetitiveHS/comments/alsclq/upcoming_balance_update_february_2019/");
            var post = reddit.GetPost(uri);

            int cont1, cont2, cont3, cont4, cont5 = 0;

            string total = "";

            foreach (var Comment in post.Comments)
            {
                Console.WriteLine("Comentário:"+Comment.Body);
                total = total + " " + Comment.Body;
                if (Comment.Comments.Count > 0)
                {
                    foreach(var Subcomment in Comment.Comments)
                    {
                        Console.WriteLine("Comentário:" + Subcomment.Body);
                        total = total + " " + Subcomment.Body;
                        if (Subcomment.Comments.Count > 0)
                        {
                            foreach (var Subsubcomment in Subcomment.Comments)
                            {
                                Console.WriteLine("Comentário:" + Subsubcomment.Body);
                                total = total + " " + Subsubcomment.Body;
                                if (Subsubcomment.Comments.Count > 0)
                                {
                                    foreach (var Subsubsubcomment in Subsubcomment.Comments)
                                    {
                                        Console.WriteLine("Comentário:" + Subsubsubcomment.Body);
                                        total = total + " " + Subsubsubcomment.Body;

                                    }
                                }
                            }
                        }
                    }
                }
            }

            cont1 = Regex.Matches(total, "Cold Blood", RegexOptions.IgnoreCase).Count;
            Console.WriteLine("Cold Blood ocorrencias:" + cont1);
            cont2 = Regex.Matches(total, "Flametongue Totem", RegexOptions.IgnoreCase).Count;
            Console.WriteLine("Flametongue Totem ocorrencias:" + cont2);
            cont3 = Regex.Matches(total, "Equality", RegexOptions.IgnoreCase).Count;
            Console.WriteLine("Equality ocorrencias:" + cont3);
            cont4 = Regex.Matches(total, "Hunter's Mark", RegexOptions.IgnoreCase).Count + Regex.Matches(total, "Hunters Mark", RegexOptions.IgnoreCase).Count;
            Console.WriteLine("Hunter's Mark ocorrencias:" + cont4);
            cont5 = Regex.Matches(total, "Lesser Emerald Spellstone", RegexOptions.IgnoreCase).Count + Regex.Matches(total, "Emerald Spellstone", RegexOptions.IgnoreCase).Count ;
            Console.WriteLine("Lesser Emerald Spellstone ocorrencias:" + cont5);




        }
    }
}
